const slider = document.querySelector(".slider");
/* console.log(slider); */

let sliderleft = slider.getBoundingClientRect();
/* console.log(sliderleft); */

const vegeText = document.querySelector(".vegeText");

let vegeleft = vegeText.getBoundingClientRect();
/* console.log(vegeleft); */

/* if (vegeleft >= sliderleft) {
  vegeText.style.color = "hotpink";
} else if (vegeleft <= sliderleft) {
  vegeText.style.color = "blue";
}
 */
